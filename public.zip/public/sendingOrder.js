// sendingOrder.js  — optimized on top of version #2

async function sendDirect(timerText, tafelNr, orderLineCount, newInvoiceNumber, Bestelling) {
  console.log("sendDirect called with:", { Bestelling, newInvoiceNumber });

  const WebHookEl = document.getElementById('webhook');
  const WebHook = WebHookEl?.innerText?.trim?.();
  if (!WebHook) {
    console.error("❌ WebHook URL 未设置（#webhook 元素不存在或无文本）");
    return "Fout: webhook niet ingesteld.";
  }

  const baseInfo = {
    taskNumber: "775352821",
    orderDrive: "S",
    printTicket: 1,
    tableNameString: tafelNr,
    allInOrderKeerPlus: 1,
    cashierID: 1,
    workerID: 4,
    articleCount: 0,
  };

  // —— 清洗文本工具 ——
  function cleanText(str) {
  if (typeof str !== "string") return "";
  // 只去除HTML标签，保留+、-等符号
  str = str.replace(/<[^>]+>/g, "");
  str = str.trim();
  return str;
  }

  // —— 订单内容格式化（带自动清洗）——
  function formatContent(BestellingInput, baseInfoRef) {
    console.log("Bestelling before processing:", BestellingInput);

    let arr = BestellingInput;
    if (typeof arr === "string") {
      try {
        arr = JSON.parse(arr);
        console.log("Parsed Bestelling:", arr);
      } catch (error) {
        console.error("Error parsing Bestelling:", error);
        return "";
      }
    }

    if (!Array.isArray(arr)) {
      console.error("Bestelling is not an array or could not be parsed as an array.");
      return "";
    }

    // 转成对象数组，自动清洗 sku/description
    const items = arr.map((item) => ({
      sku: cleanText(item?.[1]) || "N/A",
      price: item?.[3] ?? 0,
      quantity: item?.[2] ?? 0,
      description: cleanText(item?.[5]) || "No description",
    }));
    baseInfoRef.articleCount = items.length;

    let formattedString =
      `TASKNUMBER=${baseInfoRef.taskNumber}\n\n` +
      `ORDER_DRIVE=${baseInfoRef.orderDrive}\n\n` +
      `PRINTTICKET=${baseInfoRef.printTicket}\n\n` +
      `TableNameString=${baseInfoRef.tableNameString}\n\n` +
      `AllInOrderKeerPlus=${baseInfoRef.allInOrderKeerPlus}\n\n` +
      `CashierID=${baseInfoRef.cashierID}\n\n` +
      `WorkerID=${baseInfoRef.workerID}\n\n`;

    items.forEach((item, index) => {
      const itemSku = item.sku ?? "N/A";
      const itemPrice = (item.price !== undefined && item.price !== "")
        ? parseFloat(Number(item.price).toFixed(2))
        : 0;
      const itemQuantity = item.quantity ?? 0;
      const itemDescription = item.description ?? "No description";

      formattedString +=
        `${index}_ArtNRchar=${itemSku}\n` +
        `${index}_ArtCount=${itemQuantity}\n` +
        `${index}_ArtPrice=${itemPrice}\n` +
        `${index}_ArtEuroName=${itemDescription}\n`;
    });

    formattedString += `\nArticleCount=${items.length}`;
    console.log("Formatted String:", formattedString);
    return formattedString;
  }

  // —— 仅用于消息文本：保证 Bestelling 为数组（防止未解析导致消息异常）——
  function normalizeBestellingForMessage(raw) {
    if (typeof raw === "string") {
      try { return JSON.parse(raw); } catch { return []; }
    }
    return Array.isArray(raw) ? raw : [];
  }

  // —— 获取本地 WhatsApp Web 状态（带超时）——
  async function isLocalWhatsAppOnline(statusUrl = "https://whatsapp.cislink.nl/status", timeoutMs = 2500) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const resp = await fetch(statusUrl, { signal: ctrl.signal });
      if (!resp.ok) return false;
      const data = await resp.json().catch(() => ({}));
      return data?.state === "CONNECTED";
    } catch (err) {
      console.warn("⚠️ 获取本地 WhatsApp 状态失败：", err?.message || err);
      return false;
    } finally {
      clearTimeout(timer);
    }
  }

  // —— 统一的发送 WhatsApp（本地优先→云端回退），不会 throw —— 
  async function sendWhatsAppWithFallback(recipients, messageText) {
    // 依赖注入校验
    const sendViaLocal = window?.sendOrderViaLocalWWeb;
    const sendViaCloud = window?.sendWhatsAppMessage;

    if (!Array.isArray(recipients) || recipients.length === 0) {
      console.warn("⚠️ WhatsApp 收件人为空，跳过发送");
      return { success: false, reason: "no_recipients" };
    }
    if (typeof messageText !== "string" || !messageText.trim()) {
      console.warn("⚠️ WhatsApp 文本为空，跳过发送");
      return { success: false, reason: "empty_message" };
    }

    let used = "none";
    try {
      const localOnline = await isLocalWhatsAppOnline();
      if (localOnline && typeof sendViaLocal === "function") {
        used = "local";
        const r = await sendViaLocal(recipients, messageText);
        logWhatsAppResults(r, "本地 WhatsApp");
        if (isResultSuccess(r)) return { success: true, used };
        console.warn("⚠️ 本地 WhatsApp 发送失败，尝试云端回退…");
      }

      if (typeof sendViaCloud === "function") {
        used = "cloud";
        const r = await sendViaCloud(recipients, messageText);
        logWhatsAppResults(r, "WhatsApp Cloud");
        if (isResultSuccess(r)) return { success: true, used };
      } else {
        console.warn("⚠️ 未提供云端发送函数 sendWhatsAppMessage，无法回退");
      }

      return { success: false, used };
    } catch (err) {
      console.warn("⚠️ WhatsApp 发送异常：", err?.message || err);
      return { success: false, used, error: err?.message || String(err) };
    }
  }

  function isResultSuccess(result) {
    if (!result) return false;
    if (Array.isArray(result.results)) {
      // 批量：只要全部成功才算成功；如需“部分成功算成功”，可改为 some()
      return result.results.every(r => r?.success === true);
    }
    return !!result.success;
  }

  function logWhatsAppResults(result, label) {
    if (Array.isArray(result?.results)) {
      result.results.forEach(r => {
        if (!r?.success) console.warn(`⚠️ ${label} 失败:`, r?.to, r?.error);
      });
    } else if (!result?.success) {
      console.warn(`⚠️ ${label} 失败:`, result?.error);
    } else {
      console.log(`✅ ${label} 发送成功`);
    }
  }

  // —— 生成订单文本 —— 
  const formattedContent = formatContent(Bestelling, baseInfo);

  // —— 发送到 WebHook —— 
  const orderDetails = {
    fileName: `Order_${tafelNr}_C6K1.${newInvoiceNumber}`,
    content: formattedContent,
    serieNum: newInvoiceNumber,
    TafelNr: tafelNr,
  };
  console.log("Order details payload:", JSON.stringify(orderDetails));

  try {
    const response = await fetch(WebHook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderDetails),
    });

    console.log("Webhook response code:", response.status);

    if (!response.ok) {
      console.error("Unexpected response code:", response.status);
      if (response.status === 502) {
        throw new Error("502 Bad Gateway: De server is niet beschikbaar. Probeer later opnieuw.");
      }
      throw new Error(`Unexpected response code: ${response.status}`);
    }

    // —— WebHook 成功后：尝试发送 WhatsApp（不阻断主流程）——
    try {
      await (order?.waitForAppConfig?.()); // 等待配置加载（存在性可选）
      const recipientPhone = AppConfig?.whatsappPhone;
      const whatsappBerichtAan = AppConfig?.whatsappBerichtAan;

      if (whatsappBerichtAan) {
        if (recipientPhone) {
          const parsedForMsg = normalizeBestellingForMessage(Bestelling);
          if (typeof window?.buildWhatsAppMessageText === "function") {
            const messageText = window.buildWhatsAppMessageText(
              parsedForMsg, tafelNr, newInvoiceNumber, orderLineCount
            );
            const recipients = Array.isArray(recipientPhone) ? recipientPhone : [recipientPhone];
            const waResult = await sendWhatsAppWithFallback(recipients, messageText);
            if (!waResult.success) {
              console.warn("⚠️ WhatsApp 通知未成功（不影响下单成功）：", waResult);
            }
          } else {
            console.warn("⚠️ 缺少 buildWhatsAppMessageText 函数，跳过 WhatsApp 通知");
          }
        } else {
          console.warn("⚠️ AppConfig.whatsappPhone 未设置，跳过 WhatsApp 通知");
        }
      } else {
        console.log("ℹ️ whatsappBerichtAan is false, skipping WhatsApp notification.");
      }
    } catch (notifyErr) {
      console.warn("⚠️ 发送 WhatsApp 通知过程出现异常（不影响下单）：", notifyErr?.message || notifyErr);
    }

    // —— 与第一段保持一致：给调用方明确的成功返回值 —— 
    return "Bestelling succesvol verzonden!";

  } catch (error) {
    console.error("Error in sendDirect:", error?.toString?.() || error);
    return `Fout bij het verzenden van de bestelling: ${error.message || String(error)}`;
  }
}
